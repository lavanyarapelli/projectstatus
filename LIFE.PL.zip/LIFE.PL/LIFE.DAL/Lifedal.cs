﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using LIFE.Entities;
using LIFE.Exceptions;

namespace LIFE.DAL
{
    public class Lifedal
    {
        public static string FileName = @"InsurancePlan";
        
        public static List<InsurancePlan> InsurancePlanList = new List<InsurancePlan>();

            public bool AddInsurancePlanDAL(InsurancePlan InsurancePlan)
            {
                bool InsurancePlanAdded = false;
                try
                {
                    InsurancePlanList.Add(InsurancePlan);
                    InsurancePlanAdded = true;
                    Serialization();
                }

                catch (InsurancePlanException ex)
                {
                    throw new InsurancePlanException(ex.Message);
                }
                    return InsurancePlanAdded;

            }

            public List<InsurancePlan> GetListInsurancePlanDAL()
                    {
                         Deserialization();
            try
            {
                return InsurancePlanList;
            }

            catch (InsurancePlanException ex)
            {
                throw new InsurancePlanException(ex.Message);
            }

        }

            public InsurancePlan SearchInsurancePlanDAL(string searchPlanNo)
            {
                Deserialization();
                InsurancePlan searchInsurancePlan = null;
                    try
                    {
                    searchInsurancePlan = InsurancePlanList.Find(InsurancePlan => InsurancePlan.PlanNo == searchPlanNo);
                    }
                    catch (SystemException ex)
                    {
                        throw new InsurancePlanException(ex.Message);
                    }
                    return searchInsurancePlan;
            }

            public bool UpdateInsurancePlanDAL(InsurancePlan updateInsurancePlan)
            {
                Deserialization();
                bool InsurancePlanUpdated = false;
                    try
                    {
                        for (int i = 0; i < InsurancePlanList.Count; i++)
                        {
                            if (InsurancePlanList[i].PlanNo == updateInsurancePlan.PlanNo)
                            {
                            updateInsurancePlan.Name = InsurancePlanList[i].Name;
                            updateInsurancePlan.Description = InsurancePlanList[i].Description;
                            updateInsurancePlan.DeathBenefit = InsurancePlanList[i].DeathBenefit;
                            updateInsurancePlan.MaturityBenifit = InsurancePlanList[i].MaturityBenifit;
                            updateInsurancePlan.ParticipationInProfits = InsurancePlanList[i].ParticipationInProfits;
                            updateInsurancePlan.PlanParameters = InsurancePlanList[i].PlanParameters;

                            InsurancePlanUpdated = true;
                            }
                        Serialization();
                    }
                    }
                    catch (SystemException ex)
                    {
                        throw new InsurancePlanException(ex.Message);
                    }
                    return InsurancePlanUpdated;

            }

            public bool DeleteInsurancePlanDAL(string deletePlanNo)
            {
                Deserialization();
                bool InsurancePlanDeleted = false;
                    try
                    {
                    InsurancePlan deleteInsurancePlan = InsurancePlanList.Find(InsurancePlan => InsurancePlan.PlanNo == deletePlanNo);

                        if (deleteInsurancePlan != null)
                        {
                        InsurancePlanList.Remove(deleteInsurancePlan);
                        InsurancePlanDeleted = true;
                        }
                    Serialization();
                }

                catch (SystemException ex)
                {
                    throw new InsurancePlanException(ex.Message);
                }
                return InsurancePlanDeleted;

            }

        public void Serialization()
        {
            try
            {
                FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Write);
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, InsurancePlanList);
                fs.Close();
                //Carlist.Clear();
            }
            catch (SystemException ex)
            {
                throw new InsurancePlanException(ex.Message);
            }
        }
        public void Deserialization()
        {
            try
            {
                FileStream fs = new FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Read);
                BinaryFormatter bf = new BinaryFormatter();
                //Carlist.Clear();
                InsurancePlanList = bf.Deserialize(fs) as List<InsurancePlan>;
                fs.Close();
            }
            catch (SystemException ex)
            {
                throw new InsurancePlanException(ex.Message);
            }

        }
    }
    }


