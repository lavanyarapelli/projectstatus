﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LIFE.BAL;
using LIFE.Entities;
using LIFE.Exceptions;


namespace LIFE.PL
{
    class Lifepl
    {

        static void Main(string[] args)
        {
            Lifepl lf = new Lifepl();
            lf.PrintMenu();
        }
        private  void PrintMenu()
        {
            char ch; 
            do
            {
                PrintMenuDetails();
                int choice;
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Administrator();
                        break;
                    case 2:
                        Customer();
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("y for catalog and N for exit");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch == 'y' || ch == 'Y');
        }
        
            private static void Administrator()
            {

            

            AdministratorPlanDetails();
                int choice;
                Console.WriteLine("Enter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            AddInsurancePlan();
                            break;
                        case 2:
                    ViewInsurancePlan();
                            break;
                        case 3:
                            SearchInsurancePlan();
                            break;
                        case 4:
                            UpdateInsurancePlan();
                            break;
                        case 5:
                            DeleteInsurancePlan();
                            break;
                        case 6:
                            return;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                }
                
        }

            private static void Customer()
            {

        
                
                
                CustomerPlanDetails();
                int choice;
                Console.WriteLine("Enter your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            SearchInsurancePlan();
                            break;
                        case 2:
                            ViewInsurancePlan();
                            break;
                        case 3:
                            UpdateInsurancePlan();
                            break;
                        case 4:
                            ApplyOnline();
                            break;
                        case 5:
                            return;

                default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                
            
       
            }

           
        private static void PrintMenuDetails()
        {
            Console.WriteLine("\n*********** Life Insurance Management System ***********");
            Console.WriteLine("\n***********Insurance Plan Details ***********");
            Console.WriteLine("1. Administrator");
            Console.WriteLine("2. Customer");

        }
        private static void AdministratorPlanDetails()
        {
            Console.WriteLine("\n***********Insurance Plan Menu ***********");
            Console.WriteLine("1. Add InsurancePlan");
            Console.WriteLine("2. List All InsurancePlan");
            Console.WriteLine("3. Search InsurancePlan by PlanNo");
            Console.WriteLine("4. Update InsurancePlan");
            Console.WriteLine("5. Delete InsurancePlan");
            Console.WriteLine("6. Exit");
            Console.WriteLine("******************************************\n");

        }


        private static void CustomerPlanDetails()
        {
            Console.WriteLine("\n***********PlanParameters Menu ***********");
            Console.WriteLine("1. Search InsurancePlan by PlanNo");
            Console.WriteLine("2. View InsurancePlan");
            Console.WriteLine("3. Update InsurancePlan");
            Console.WriteLine("4. Apply Online");
            Console.WriteLine("5. Exit");
            Console.WriteLine("******************************************\n");

        }

        private static void DeleteInsurancePlan()
        {
            try

            {
                string deletePlanNo;
                Console.WriteLine("Enter PlanNo to DeleteInsurancePlan:");
                deletePlanNo = Console.ReadLine();
                InsurancePlan deleteInsurancePlan = Lifebal.SearchInsurancePlanBAL(deletePlanNo);
                if (deleteInsurancePlan != null)
                {
                    bool InsurancePlandeleted = Lifebal.DeleteInsurancePlanBAL(deletePlanNo);
                    if (InsurancePlandeleted)
                        Console.WriteLine("InsurancePlan Deleted");
                    else
                        Console.WriteLine("InsurancePlan not Deleted ");
                }
                else
                {
                    Console.WriteLine("No InsurancePlan Details Available");
                }


            }
            catch (InsurancePlanException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateInsurancePlan()
        {
            try
            {
                string updatePlanNo;
                Console.WriteLine("Enter PlanNo to UpdateInsurancePlan:");
                updatePlanNo = Console.ReadLine();
                InsurancePlan InsurancePlan = Lifebal.SearchInsurancePlanBAL(updatePlanNo);
                if (InsurancePlan != null)
                {
                    
                    Console.WriteLine("Enter  Name :");
                    InsurancePlan.Name = Console.ReadLine();
                    Console.WriteLine("Enter Description :");
                    InsurancePlan.Description = Console.ReadLine();
                    Console.WriteLine("Enter DeathBenefit :");
                    InsurancePlan.DeathBenefit = Console.ReadLine();
                    Console.WriteLine("Enter MaturityBenefit :");
                    InsurancePlan.MaturityBenifit = Console.ReadLine();
                    Console.WriteLine("Enter ParticipationProfits :");
                    InsurancePlan.ParticipationInProfits = Console.ReadLine();

                    PlanParameters Planparameters = new PlanParameters();

                    
                    Console.WriteLine(" Enter Age Of Entry :");
                    Planparameters.AgeOfEntry =Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine(" Enter Premium Paying Mode :");                   
                    Planparameters.PremiumPayingMode = Console.ReadLine();
                    Console.WriteLine(" Enter Policy Term :");
                    Planparameters.PolicyTerm = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine(" Enter Basic Sum Assured :");
                    Planparameters.BasicSumAssured = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine(" Enter Policy Revival :");
                    Planparameters.PolicyRevival = Console.ReadLine();
                    Console.WriteLine(" Enter Premium Mode Rebate :");
                    Planparameters.PremiumModeRebate = Console.ReadLine();
                    Console.WriteLine(" Enter Loan :");
                    Planparameters.Loan = Console.ReadLine();
                    Console.WriteLine(" Enter Surrender :");
                    Planparameters.Surrender = Console.ReadLine();



                    InsurancePlan.PlanParameters = Planparameters;
                    bool guestUpdated = Lifebal.UpdateInsurancePlanBAL(InsurancePlan);
                    if (guestUpdated)
                        Console.WriteLine("InsurancePlan Details Updated");
                    else
                        Console.WriteLine("InsurancePlan Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No InsurancePlan Details Available");
                }


            }
            catch (InsurancePlanException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchInsurancePlan()
        {
            try
            {
                string searchPlanNo;
                Console.WriteLine("Enter PlanNo to SearchInsurancePlan:");
                searchPlanNo = Console.ReadLine();
                InsurancePlan InsurancePlan = Lifebal.SearchInsurancePlanBAL(searchPlanNo);
                if (InsurancePlan != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PlanNo\t\tName\t\tDescription\t\tDeathBenefitt\tMaturityBenefitt\tParticipationInProfitst\tAgeOfEntry" +
                        "\t\tPremiumPayingMode\t\tPolicyTerm\t\tBasicSumAssured\t\tPolicyRevival\t\tPremiumPayinRebate\t\tLoan\t\tSurrender");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t{9}\t\t{10}\t\t{11}\t\t{12}\t\t{13}",
                        InsurancePlan.PlanNo, InsurancePlan.Name, InsurancePlan.Description, InsurancePlan.DeathBenefit,
                                InsurancePlan.MaturityBenifit, InsurancePlan.ParticipationInProfits, InsurancePlan.PlanParameters.AgeOfEntry,
                                InsurancePlan.PlanParameters.PremiumPayingMode, InsurancePlan.PlanParameters.PolicyTerm,
                                InsurancePlan.PlanParameters.BasicSumAssured,
                                InsurancePlan.PlanParameters.PolicyRevival, InsurancePlan.PlanParameters.PremiumModeRebate, 
                                InsurancePlan.PlanParameters.Loan, InsurancePlan.PlanParameters.Surrender);
                }
                else
                {
                    Console.WriteLine("No InsurancePlan Details Available");
                }

            }
            catch (InsurancePlanException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void ViewInsurancePlan()
        {
            try
            {
                Console.WriteLine("Enter details to ViewInsurancePlan:");
                // InsurancePlan InsurancePlan = new InsurancePlan();
                List<InsurancePlan> InsurancePlanlist = Lifebal.GetListInsurancePlanBAL();
                if (InsurancePlanlist != null)
                {
                    foreach (InsurancePlan InsurancePlan in InsurancePlanlist)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("PlanNo\t\tName\t\tDescription\t\tDeathBenefitt\tMaturityBenefitt\tParticipationInProfitst\tAgeOfEntry" +
                            "\t\tPremiumPayingMode\t\tPolicyTerm\t\tBasicSumAssured\t\tPolicyRevival\t\tPremiumPayinRebate\t\tLoan\t\tSurrender");
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t{9}\t\t{10}\t\t{11}\t\t{12}\t\t{13}",
                            InsurancePlan.PlanNo, InsurancePlan.Name, InsurancePlan.Description, InsurancePlan.DeathBenefit,
                                    InsurancePlan.MaturityBenifit, InsurancePlan.ParticipationInProfits, InsurancePlan.PlanParameters.AgeOfEntry,
                                    InsurancePlan.PlanParameters.PremiumPayingMode, InsurancePlan.PlanParameters.PolicyTerm,
                                    InsurancePlan.PlanParameters.BasicSumAssured,
                                    InsurancePlan.PlanParameters.PolicyRevival, InsurancePlan.PlanParameters.PremiumModeRebate,
                                    InsurancePlan.PlanParameters.Loan, InsurancePlan.PlanParameters.Surrender);
                    }
                }
                else
                {
                    Console.WriteLine("No InsurancePlan Details Available");
                }
            }
            catch (InsurancePlanException ex)
            { 
         
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddInsurancePlan()
        {
            try
            {
                Console.WriteLine("Enter details to AddInsurancePlan:");
                InsurancePlan InsurancePlan = new InsurancePlan();
                Console.WriteLine("Enter PlanNo :");
                InsurancePlan.PlanNo = Console.ReadLine();
                Console.WriteLine("Enter  Name :");
                InsurancePlan.Name = Console.ReadLine();
                Console.WriteLine("Enter Description :");
                InsurancePlan.Description = Console.ReadLine();
                Console.WriteLine("Enter DeathBenefit :");
                InsurancePlan.DeathBenefit = Console.ReadLine();
                Console.WriteLine("Enter MaturityBenefit :");
                InsurancePlan.MaturityBenifit = Console.ReadLine();
                Console.WriteLine("Enter ParticipationProfits :");
                InsurancePlan.ParticipationInProfits = Console.ReadLine();
                PlanParameters Planparameters = new PlanParameters();


                Console.WriteLine(" Enter Age Of Entry :");
                Planparameters.AgeOfEntry = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(" Enter Premium Paying Mode :");
                Planparameters.PremiumPayingMode = Console.ReadLine();
                Console.WriteLine(" Enter Policy Term :");
                Planparameters.PolicyTerm = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(" Enter Basic Sum Assured :");
                Planparameters.BasicSumAssured = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(" Enter Policy Revival :");
                Planparameters.PolicyRevival = Console.ReadLine();
                Console.WriteLine(" Enter Premium Mode Rebate :");
                Planparameters.PremiumModeRebate = Console.ReadLine();
                Console.WriteLine(" Enter Loan :");
                Planparameters.Loan = Console.ReadLine();
                Console.WriteLine(" Enter Surrender :");
                Planparameters.Surrender = Console.ReadLine();
                InsurancePlan.PlanParameters = Planparameters;
                bool InsurancePlanAdded = Lifebal.AddInsurancePlanBAL(InsurancePlan);
                if (InsurancePlanAdded)
                    Console.WriteLine("InsurancePlan Added");
                else
                    Console.WriteLine("InsurancePlan not Added");
            }
            catch (InsurancePlanException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void ApplyOnline()
        {
            try
            {
                Console.WriteLine("Enter details to ApplyOnline:");
                InsurancePlan InsurancePlan = new InsurancePlan();
                Console.WriteLine("Enter PlanNo :");
                InsurancePlan.PlanNo = Console.ReadLine();
                Console.WriteLine("Enter  Name :");
                InsurancePlan.Name = Console.ReadLine();
                Console.WriteLine("Enter Description :");
                InsurancePlan.Description = Console.ReadLine();
                Console.WriteLine("Enter DeathBenefit :");
                InsurancePlan.DeathBenefit = Console.ReadLine();
                Console.WriteLine("Enter MaturityBenefit :");
                InsurancePlan.MaturityBenifit = Console.ReadLine();
                Console.WriteLine("Enter ParticipationProfits :");
                InsurancePlan.ParticipationInProfits = Console.ReadLine();
                PlanParameters Planparameters = new PlanParameters();


                Console.WriteLine(" Enter Age Of Entry :");
                Planparameters.AgeOfEntry = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(" Enter Premium Paying Mode :");
                Planparameters.PremiumPayingMode = Console.ReadLine();
                Console.WriteLine(" Enter Policy Term :");
                Planparameters.PolicyTerm = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(" Enter Basic Sum Assured :");
                Planparameters.BasicSumAssured = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(" Enter Policy Revival :");
                Planparameters.PolicyRevival = Console.ReadLine();
                Console.WriteLine(" Enter Premium Mode Rebate :");
                Planparameters.PremiumModeRebate = Console.ReadLine();
                Console.WriteLine(" Enter Loan :");
                Planparameters.Loan = Console.ReadLine();
                Console.WriteLine(" Enter Surrender :");
                Planparameters.Surrender = Console.ReadLine();
                InsurancePlan.PlanParameters = Planparameters;
                bool InsurancePlanAdded = Lifebal.AddInsurancePlanBAL(InsurancePlan);
                if (InsurancePlanAdded)
                    Console.WriteLine("InsurancePlan applied Succesfully");
                else
                    Console.WriteLine("InsurancePlan not applied Succesfully");
            }
            catch (InsurancePlanException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        }

            
    }

