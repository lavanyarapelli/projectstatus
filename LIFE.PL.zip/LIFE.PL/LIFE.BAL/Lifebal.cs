﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LIFE.Exceptions;
using LIFE.Entities;
using LIFE.DAL;
using System.Text.RegularExpressions;

namespace LIFE.BAL
{
    public class Lifebal
    {
        private static bool ISValid(InsurancePlan InsurancePlan)   //validation is done on inputs
        {
            StringBuilder errorMessage = new StringBuilder();
            bool valid = true;

            if (InsurancePlan.PlanNo == string.Empty || InsurancePlan.Name == string.Empty ||
                InsurancePlan.MaturityBenifit == string.Empty || InsurancePlan.ParticipationInProfits == string.Empty ||
                InsurancePlan.DeathBenefit == string.Empty ||Convert.ToString( InsurancePlan.PlanParameters.AgeOfEntry).Length==0 || 
                InsurancePlan.PlanParameters.PremiumPayingMode ==string.Empty ||  Convert.ToString(InsurancePlan.PlanParameters.PolicyTerm).Length == 0
                || Convert.ToString(InsurancePlan.PlanParameters.BasicSumAssured).Length == 0 || InsurancePlan.PlanParameters.PolicyRevival == string.Empty
                || InsurancePlan.PlanParameters.PremiumModeRebate == string.Empty || InsurancePlan.PlanParameters.Loan == string.Empty
                || InsurancePlan.PlanParameters.Surrender == string.Empty)
            {
                Console.WriteLine("All Fields are Mandatory");
            }
            else if (!Regex.IsMatch(InsurancePlan.PlanNo, "^([A-Z]{2})-([0-9]{4})$"))
            {
                valid = false;
                errorMessage.Append("PlanNo must be in correct format" + Environment.NewLine);
            }

           else if (InsurancePlan.PlanParameters.PremiumPayingMode != "Yearly" &&
                InsurancePlan.PlanParameters.PremiumPayingMode != "HalfYearly" &&
                InsurancePlan.PlanParameters.PremiumPayingMode != "Quarterly")
            {
                valid = false;
                errorMessage.Append("Premium paying mode  must be in correct format" + Environment.NewLine);
            }

            else if(InsurancePlan.PlanParameters.AgeOfEntry<=18 && InsurancePlan.PlanParameters.AgeOfEntry >= 50)
            {
                valid = false;
                errorMessage.Append("Age of Entry  should be be greater than 18 and less than 50" + Environment.NewLine);
            }
            else if (InsurancePlan.PlanParameters.PolicyTerm <= 18 && InsurancePlan.PlanParameters.PolicyTerm >= 35)
            {
                valid = false;
                errorMessage.Append("Policy Term should be greater than 18 and less than 35" + Environment.NewLine);
            }
            else if (InsurancePlan.PlanParameters.BasicSumAssured <= 10000 )
            {
                valid = false;
                errorMessage.Append("Basic Sum Assured should be greater than 10000" + Environment.NewLine);
            }
            if (!valid)
            {
                throw new InsurancePlanException(errorMessage.ToString());
            }

            return valid;
        }
        


        public static bool AddInsurancePlanBAL(InsurancePlan InsurancePlan)
            {
                bool InsurancePlanAdded = false;
            try
            {
                if (ISValid(InsurancePlan))
                {
                   Lifedal Lifedal = new Lifedal();
                    InsurancePlanAdded = Lifedal.AddInsurancePlanDAL(InsurancePlan);
                }
                else
                {
                    Console.WriteLine("Details are not in correct format");
                }
            
                }
                catch (InsurancePlanException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return InsurancePlanAdded;
            }
        

        public static List<InsurancePlan> GetListInsurancePlanBAL()
            {
                List<InsurancePlan> InsurancePlanList = null;
                try
                {
                Lifedal Lifedal = new Lifedal();
                InsurancePlanList = Lifedal.GetListInsurancePlanDAL();
                }
                catch (InsurancePlanException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return InsurancePlanList;
            }

            public static InsurancePlan SearchInsurancePlanBAL(string searchPlanNO)
            {
            InsurancePlan searchInsurancePlan = null;
                try
                {
                Lifedal Lifedal = new Lifedal();
                searchInsurancePlan = Lifedal.SearchInsurancePlanDAL(searchPlanNO);
                }
                catch (InsurancePlanException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                return searchInsurancePlan;

            }

            public static bool UpdateInsurancePlanBAL(InsurancePlan updateInsurancePlan)
            {
                bool InsurancePlanUpdated = false;
                try
                {
                if (ISValid(updateInsurancePlan))
                {
                    Lifedal Lifedal = new Lifedal();
                    InsurancePlanUpdated = Lifedal.UpdateInsurancePlanDAL(updateInsurancePlan);
                }
                else
                {
                    Console.WriteLine("Details are not in correct format");
                }
                
                    
                }
                catch (InsurancePlanException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return InsurancePlanUpdated;
            }

            public static bool DeleteInsurancePlanBAL(string deletePlanNO)
            {
                bool InsurancePlanDeleted = false;
            try
            {

                Lifedal Lifedal = new Lifedal();
                InsurancePlanDeleted = Lifedal.DeleteInsurancePlanDAL(deletePlanNO);
            
                }
                catch (InsurancePlanException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return InsurancePlanDeleted;
            }

        }
    }


