﻿using System;

namespace LIFE.Entities
{
    [Serializable]
    public  class InsurancePlan
    {
        
        public string PlanNo { get; set; }
            public string Name { get; set; }
            public string Description { get; set; }
            public string DeathBenefit { get; set; }
            public string MaturityBenifit { get; set; }
            public string ParticipationInProfits { get; set; }
         public PlanParameters PlanParameters { get; set; }
        
    }
}
