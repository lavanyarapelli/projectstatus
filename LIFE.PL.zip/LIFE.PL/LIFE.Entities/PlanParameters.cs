﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LIFE.Entities
{
    [Serializable]
    public class PlanParameters
    {
        
        public string PlanNo { get; set; }
        public int AgeOfEntry { get; set; }
        public string PremiumPayingMode { get; set; }
        public int PolicyTerm { get; set; }
        public int BasicSumAssured { get; set; }
        public string PolicyRevival { get; set; }
        public string PremiumModeRebate { get; set; }
        public string Loan { get; set; }
        public string Surrender { get; set; }
    }
}
