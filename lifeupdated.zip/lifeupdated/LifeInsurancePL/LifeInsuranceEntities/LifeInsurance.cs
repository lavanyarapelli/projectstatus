﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LifeInsuranceEntities
{
    public class LifeInsurance
    {
        public int PlanNo { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string DeathBenefit { get; set; }
        public string MaturityBenifit { get; set; }
        public string ParticipationInProfits { get; set; }
        public int PlanParametersId { get; set; }

    }
}
