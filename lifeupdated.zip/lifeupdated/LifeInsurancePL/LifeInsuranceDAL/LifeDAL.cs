﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LifeInsuranceEntities;
using LifeInsuranceException;


namespace LifeInsuranceDAL
{
    public class LifeDAL
    {
        public bool AddLifeInsuranceDAL(LifeInsurance objLifeInsurance)
        {
            bool LifeInsuranceAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["LifeConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("InsertLifeInsurance", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PlanNo = new SqlParameter("@PlanNo", objLifeInsurance.PlanNo);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", objLifeInsurance.Name);
                SqlParameter objSqlParam_Description = new SqlParameter("@Description", objLifeInsurance.Description);
                SqlParameter objSqlParam_DeathBenefit = new SqlParameter("@DeathBenefit", objLifeInsurance.DeathBenefit);
                SqlParameter objSqlParam_MaturityBenifit = new SqlParameter("@MaturityBenifit", objLifeInsurance.MaturityBenifit);
                SqlParameter objSqlParam_ParticipationInProfits = new SqlParameter("@ParticipationInProfits", objLifeInsurance.ParticipationInProfits);
                SqlParameter objSqlParam_PlanParametersId = new SqlParameter("@PlanParametersId", objLifeInsurance.PlanParametersId);
                 

                //


                objCom.Parameters.Add(objSqlParam_PlanNo);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Description);
                objCom.Parameters.Add(objSqlParam_DeathBenefit);
                objCom.Parameters.Add(objSqlParam_MaturityBenifit);
                objCom.Parameters.Add(objSqlParam_ParticipationInProfits);
                objCom.Parameters.Add(objSqlParam_PlanParametersId);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                LifeInsuranceAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new LifeException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return LifeInsuranceAdded;
        }

        public bool UpdateLifeInsuranceDAL(LifeInsurance objLifeInsurance)
        {
            bool LifeInsuranceUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["LifeConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("UpdateLifeInsurance", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PlanNo = new SqlParameter("@PlanNo", objLifeInsurance.PlanNo);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", objLifeInsurance.Name);
                SqlParameter objSqlParam_Description = new SqlParameter("@Description", objLifeInsurance.Description);
                SqlParameter objSqlParam_DeathBenefit = new SqlParameter("@DeathBenefit", objLifeInsurance.DeathBenefit);
                SqlParameter objSqlParam_MaturityBenifit = new SqlParameter("@MaturityBenifit", objLifeInsurance.MaturityBenifit);
                SqlParameter objSqlParam_ParticipationInProfits = new SqlParameter("@ParticipationInProfits", objLifeInsurance.ParticipationInProfits);
                SqlParameter objSqlParam_PlanParametersId = new SqlParameter("@PlanParametersId", objLifeInsurance.PlanParametersId);


                //


                objCom.Parameters.Add(objSqlParam_PlanNo);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Description);
                objCom.Parameters.Add(objSqlParam_DeathBenefit);
                objCom.Parameters.Add(objSqlParam_MaturityBenifit);
                objCom.Parameters.Add(objSqlParam_ParticipationInProfits);
                objCom.Parameters.Add(objSqlParam_PlanParametersId);


                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                LifeInsuranceUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new LifeException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return LifeInsuranceUpdated;
        }

        public bool DeleteLifeInsuranceDAL(int PlanNo)
        {
            bool LifeInsuranceDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["LifeConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("DeleteLifeInsurance", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_PlanNo = new SqlParameter("@PlanNo", PlanNo);
                //
                objCom.Parameters.Add(objSqlParam_PlanNo);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                LifeInsuranceDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new LifeException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return LifeInsuranceDeleted;
        }

        public LifeInsurance SearchEmployeeDAL(int PlanNo)
        {
            LifeInsurance objLifeInsurance = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["LifeConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("SelectLifeInsurance", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                //
                SqlParameter objSqlParam_PlanNo = new SqlParameter("@PlanNo", objLifeInsurance.PlanNo);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", objLifeInsurance.Name);
                SqlParameter objSqlParam_Description = new SqlParameter("@Description", objLifeInsurance.Description);
                SqlParameter objSqlParam_DeathBenefit = new SqlParameter("@DeathBenefit", objLifeInsurance.DeathBenefit);
                SqlParameter objSqlParam_MaturityBenifit = new SqlParameter("@MaturityBenifit", objLifeInsurance.MaturityBenifit);
                SqlParameter objSqlParam_ParticipationInProfits = new SqlParameter("@ParticipationInProfits", objLifeInsurance.ParticipationInProfits);
                SqlParameter objSqlParam_PlanParametersId = new SqlParameter("@PlanParametersId", objLifeInsurance.PlanParametersId);


                //
                objSqlParam_PlanNo.Direction = ParameterDirection.Input;
                objSqlParam_Name.Direction = ParameterDirection.Output;
                objSqlParam_Description.Direction = ParameterDirection.Output;
                objSqlParam_DeathBenefit.Direction = ParameterDirection.Output;
                objSqlParam_MaturityBenifit.Direction = ParameterDirection.Output;
                objSqlParam_ParticipationInProfits.Direction = ParameterDirection.Output;
                objSqlParam_PlanParametersId.Direction = ParameterDirection.Output;

                //

                objCom.Parameters.Add(objSqlParam_PlanNo);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Description);
                objCom.Parameters.Add(objSqlParam_DeathBenefit);
                objCom.Parameters.Add(objSqlParam_MaturityBenifit);
                objCom.Parameters.Add(objSqlParam_ParticipationInProfits);
                objCom.Parameters.Add(objSqlParam_PlanParametersId);


                //

                objSqlParam_PlanNo.Value = PlanNo;

                //
                objCon.Open();
                objCom.ExecuteNonQuery();

                objLifeInsurance = new LifeInsurance();
                objLifeInsurance.PlanNo = PlanNo;
                objLifeInsurance.Name = objSqlParam_Name.Value as string;
                objLifeInsurance.Description = objSqlParam_Description.Value as string;
                objLifeInsurance.DeathBenefit = objSqlParam_DeathBenefit.Value as string;
                objLifeInsurance.MaturityBenifit = objSqlParam_MaturityBenifit.Value as string;
                objLifeInsurance.ParticipationInProfits = objSqlParam_ParticipationInProfits.Value as string;
                objLifeInsurance.PlanParametersId = Convert.ToInt32(objSqlParam_PlanParametersId.Value);
            }
            catch (SqlException objSqlEx)
            {
                throw new LifeException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objLifeInsurance;
        }

        public List<LifeInsurance> GetAllLifeInsuranceDAL()
        {
            List<LifeInsurance> objEmployees = new List<LifeInsurance>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["LifeConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("SelectLifeInsurance", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    LifeInsurance objLifeInsurance = new LifeInsurance();
                    objLifeInsurance.PlanNo  = Convert.ToInt32(objDR[0]);
                    objLifeInsurance.Name = objDR[1] as string;
                    objLifeInsurance.Description = objDR[2] as string;
                    objLifeInsurance.DeathBenefit = objDR[3] as string;
                    objLifeInsurance.MaturityBenifit= objDR[4] as string;
                    objLifeInsurance.ParticipationInProfits = objDR[5] as string;
                    objLifeInsurance.PlanParametersId = Convert.ToInt32(objDR[5]);
                    objEmployees.Add(objLifeInsurance);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new LifeException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objEmployees;
        }

        public DataTable GetPlanParametersDAL()
        {
            DataTable PlanParametersList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["LifeConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("GetPlanParameters", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                PlanParametersList = new DataTable();
                PlanParametersList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new LifeException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return PlanParametersList;
        }

        
    }
}
