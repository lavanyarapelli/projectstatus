﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LifeInsuranceBAL;
using LifeInsuranceEntities;
using LifeInsuranceException;

namespace LifeInsurancePL
{
    /// <summary>
    /// Interaction logic for AdminstratorFunctions.xaml
    /// </summary>
    public partial class AdminstratorFunctions : Window
    {
        public AdminstratorFunctions()
        {
            InitializeComponent();
        }

        private void Main_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            
            
        }

        private void Btnadd_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new AddInsurancePlan();
            

        private void Btnsearch_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new SearchInsurancePlan();
        }

        private void Btnupdate_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new UpdateInsurancePlan();
        }

        private void Btndelete_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new DeleteInsurancePlan();
        }

        private void Btnview_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new ViewInsurancePlan();
        }

        private void Btnhomepage_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}


private void BtDelete_Click(object sender, RoutedEventArgs e)
{
    try
    {


        string Model = txtModel.Text;
        Car car = null;
        bool deleted = false;

        if (txtModel.Text != "")
        {
            car = CarBL.SearchBLL(Model);
            if (car.Model != null)
            {
                deleted = CarBL.RemoveBLL(car.Model);
                if (deleted)
                    MessageBox.Show("Car Details are deleted successfully");
                else
                    MessageBox.Show("Not deleted ");
            }
            else
            {
                MessageBox.Show("Model Not found ");
            }

        }
        else
        {
            MessageBox.Show("Please enter Model to delete");
        }
    }

    catch (CarException ex)
    {
        MessageBox.Show(ex.Message);
    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message);
    }

}
private void BtUpdate_Click(object sender, RoutedEventArgs e)
{
    try
    {
        //Car car = null;
        //string Model =txtModel.Text;
        //car = CarBL.SearchBLL(Model);
        //if (car.Model!= null)
        //{
        if (txtModel.Text != String.Empty && txtAirBags.Text != String.Empty && txtBHP.Text != String.Empty && txtBootSpace.Text != String.Empty && txtEngine.Text != String.Empty && txtMileage.Text != String.Empty && txtPrice.Text != String.Empty && txtSeat.Text != String.Empty && cbMName.Text != String.Empty && cbTransmission.Text != String.Empty && cbType.Text != String.Empty)
        {

            Car c = new Car();
            c.Model = txtModel.Text;
            c.ManufacturerName = cbMName.Text;
            c.Type = cbType.Text;
            c.Engine = txtEngine.Text;
            c.BHP = Convert.ToInt32(txtBHP.Text);
            c.Transmission = cbTransmission.Text;
            c.Mileage = Convert.ToInt32(txtMileage.Text);
            c.Seats = Convert.ToInt32(txtSeat.Text);
            c.Airbags = txtAirBags.Text;
            c.BootSpace = Convert.ToInt32(txtBootSpace.Text);
            c.price = Convert.ToInt32(txtPrice.Text);
            bool updated = CarBL.ModifyBLL(c);
            if (updated)
                MessageBox.Show("Car Details are updated");
            else
                MessageBox.Show("Car Details are not updated");
        }
        else
            MessageBox.Show("All Feilds are Mandatory");

    }

    catch (CarException ex)
    {
        MessageBox.Show(ex.Message);
    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message);
    }


}
private void Btdisplay_Click(object sender, RoutedEventArgs e)
{
    try
    {
        if (cbMName.Text != "" && cbType.Text != "")
        {
            string MName, Type;
            MName = cbMName.Text;
            Type = cbType.Text;

            dgDisplayAdmin.ItemsSource = CarBL.ShowBLL(MName, Type);
            dgDisplayAdmin.Visibility = Visibility.Visible;

        }
        else
        {
            MessageBox.Show("please enter both Manufacturer Name and Car Type");
        }
    }
    catch (CarException ce)
    {
        MessageBox.Show(ce.Message);
    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message);
    }
}


private void RbAdd_Checked(object sender, RoutedEventArgs e)
{
    Refresh();
    ShowTextLabel();
    btAdd.Visibility = Visibility.Visible;



}
private void RbSearch_Checked(object sender, RoutedEventArgs e)
{
    Refresh();
    txtModel.Visibility = Visibility.Visible;
    lblModel.Visibility = Visibility.Visible;
    btSearch.Visibility = Visibility.Visible;



}
private void RbDelete_Checked(object sender, RoutedEventArgs e)
{
    Refresh();
    txtModel.Visibility = Visibility.Visible;
    lblModel.Visibility = Visibility.Visible;
    btDelete.Visibility = Visibility.Visible;
}
private void RbUpdate_Checked(object sender, RoutedEventArgs e)
{
    Refresh();
    txtModel.Visibility = Visibility.Visible;
    lblModel.Visibility = Visibility.Visible;


    MessageBox.Show("Enter Model and Click search and then edit details to update");
    btSearch.Visibility = Visibility.Visible;
    btUpdate.Visibility = Visibility.Visible;

}
private void RbDisplay_Checked(object sender, RoutedEventArgs e)
{
    Refresh();
    lblMName.Visibility = Visibility.Visible;
    lblType.Visibility = Visibility.Visible;
    cbMName.Visibility = Visibility.Visible;
    cbType.Visibility = Visibility.Visible;
    btdisplay.Visibility = Visibility.Visible;

}
public void Refresh()
{
    txtModel.Visibility = Visibility.Hidden;
    cbMName.Visibility = Visibility.Hidden;
    cbType.Visibility = Visibility.Hidden;
    txtEngine.Visibility = Visibility.Hidden;
    txtBHP.Visibility = Visibility.Hidden;
    cbTransmission.Visibility = Visibility.Hidden;
    txtMileage.Visibility = Visibility.Hidden;
    txtSeat.Visibility = Visibility.Hidden;
    txtAirBags.Visibility = Visibility.Hidden;
    txtBootSpace.Visibility = Visibility.Hidden;
    txtPrice.Visibility = Visibility.Hidden;

    lblMName.Visibility = Visibility.Hidden;
    lblModel.Visibility = Visibility.Hidden;
    lblType.Visibility = Visibility.Hidden;
    lblEngine.Visibility = Visibility.Hidden;
    lblBHP.Visibility = Visibility.Hidden;
    lblTransmission.Visibility = Visibility.Hidden;
    lblMileage.Visibility = Visibility.Hidden;
    lblSeat.Visibility = Visibility.Hidden;
    lblAirBags.Visibility = Visibility.Hidden;
    lblBootSpace.Visibility = Visibility.Hidden;
    lblPrice.Visibility = Visibility.Hidden;

    btAdd.Visibility = Visibility.Hidden;
    btSearch.Visibility = Visibility.Hidden;
    btUpdate.Visibility = Visibility.Hidden;
    btDelete.Visibility = Visibility.Hidden;
    btdisplay.Visibility = Visibility.Hidden;
    dgDisplayAdmin.Visibility = Visibility.Hidden;

}
public void ShowTextLabel()
{
    txtModel.Visibility = Visibility.Visible;
    cbMName.Visibility = Visibility.Visible;
    cbType.Visibility = Visibility.Visible;
    txtEngine.Visibility = Visibility.Visible;
    txtBHP.Visibility = Visibility.Visible;
    cbTransmission.Visibility = Visibility.Visible;
    txtMileage.Visibility = Visibility.Visible;
    txtSeat.Visibility = Visibility.Visible;
    txtAirBags.Visibility = Visibility.Visible;
    txtBootSpace.Visibility = Visibility.Visible;
    txtPrice.Visibility = Visibility.Visible;

    lblMName.Visibility = Visibility.Visible;
    lblModel.Visibility = Visibility.Visible;
    lblType.Visibility = Visibility.Visible;
    lblEngine.Visibility = Visibility.Visible;
    lblBHP.Visibility = Visibility.Visible;
    lblTransmission.Visibility = Visibility.Visible;
    lblMileage.Visibility = Visibility.Visible;
    lblSeat.Visibility = Visibility.Visible;
    lblAirBags.Visibility = Visibility.Visible;
    lblBootSpace.Visibility = Visibility.Visible;
    lblPrice.Visibility = Visibility.Visible;
    //btAdd.Visibility = Visibility.Visible;

}

private void BtHome_Click(object sender, RoutedEventArgs e)
{
    CIMS cims = new CIMS();
    this.Close();
    cims.Show();

}

private void BtRefresh_Click(object sender, RoutedEventArgs e)
{
    txtModel.Text = "";
    cbMName.Text = "";
    cbType.Text = "";
    txtAirBags.Text = "";
    txtBHP.Text = "";
    txtBootSpace.Text = "";
    txtEngine.Text = "";
    txtMileage.Text = "";
    txtPrice.Text = "";
    txtSeat.Text = "";
    cbTransmission.Text = "";
    dgDisplayAdmin.Visibility = Visibility.Hidden;


}