﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LifeInsuranceEntities;
using LifeInsuranceException;
using LifeInsuranceBAL;


namespace LifeInsurancePL
{
    /// <summary>
    /// Interaction logic for SearchInsurancePlan.xaml
    /// </summary>
    public partial class SearchInsurancePlan : Page
    {
        public SearchInsurancePlan()
        {
            InitializeComponent();

            
                int PlanNo;
            LifeInsurance LifeInsurance = null;
                try
                {
                    if (txtPlanNo.Text != "")
                    {
                    PlanNo = Convert.ToInt32(txtPlanNo.Text);
                    LifeInsurance =LifeBAL.SearchLifeInsuranceBAL(PlanNo);
                        if (LifeInsurance != null)
                        {
                            

                        
                        txtPlanNo.Text= LifeInsurance.PlanNo.ToString();
                        txtName.Text=LifeInsurance.Name ;
                        txtDescription.Text= LifeInsurance.Description;
                        txtDeathBenefit.Text=LifeInsurance.DeathBenefit ;
                        txtMaturityBenefit.Text=LifeInsurance.MaturityBenifit ;
                         txtParticipationInProfits.Text=LifeInsurance.ParticipationInProfits;
                         cbPlanParametersId.Text=LifeInsurance.PlanParametersId.ToString();

                    }
                    else
                            MessageBox.Show("Car not found");


                    }
                    else
                    {
                        MessageBox.Show("Please Enter Model to Search");
                    }
                }

                catch (LifeException ce)
                {
                    MessageBox.Show(ce.Message);

                }
                catch (Exception se)
                {
                    MessageBox.Show(se.Message);
                }

        }
    }
}
