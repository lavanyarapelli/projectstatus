﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LifeInsuranceEntities;
using LifeInsuranceException;
using LifeInsuranceBAL;

namespace LifeInsurancePL
{
    /// <summary>
    /// Interaction logic for AddInsurancePlan.xaml
    /// </summary>
    public partial class AddInsurancePlan : Page
    {
        public AddInsurancePlan()
        {
            InitializeComponent();

            try
            {
                if (txtPlanNo.Text != String.Empty && txtName.Text != String.Empty 
                    && txtDescription.Text != String.Empty && txtDeathBenefit.Text != String.Empty 
                    && txtMaturityBenefit.Text != String.Empty && txtParticipationInProfits.Text != String.Empty 
                   && cbPlanParametersId.Text!=string.Empty)
                {
                    LifeInsurance LifeInsurance = new LifeInsurance();
                    LifeInsurance.PlanNo = Convert.ToInt32(txtPlanNo.Text);
                    LifeInsurance.Name = txtName.Text;
                    LifeInsurance.Description = txtDescription.Text;
                    LifeInsurance.DeathBenefit = txtDeathBenefit.Text;
                    LifeInsurance.MaturityBenifit = txtMaturityBenefit.Text;
                    LifeInsurance.ParticipationInProfits = txtParticipationInProfits.Text;
                    LifeInsurance.PlanParametersId = Convert.ToInt32(cbPlanParametersId.Text);


                    bool added = LifeBAL.AddLifeInsuranceBAL(LifeInsurance);
                    if (added)
                        MessageBox.Show("Insurance Plan added Successfully");

                    else
                        MessageBox.Show("Details are not added ");
                }
                else
                    MessageBox.Show("All Feilds are Mandatory");


            }
            catch (LifeException ce)
            {
                MessageBox.Show(ce.Message);

            }
            catch (Exception se)
            {
                MessageBox.Show(se.Message);
            }
        }
    }


}

