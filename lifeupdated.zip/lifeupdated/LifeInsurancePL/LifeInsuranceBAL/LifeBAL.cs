﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LifeInsuranceDAL;
using LifeInsuranceEntities;
using LifeInsuranceException;

namespace LifeInsuranceBAL
{
    public class LifeBAL
    {

        private static bool ISValid(LifeInsurance LifeInsurance)   //validation is done on inputs
        {
            StringBuilder errorMessage = new StringBuilder();
            bool valid = true;

            if 
             (Convert.ToString(LifeInsurance.PlanNo) == string.Empty || LifeInsurance.Name == string.Empty ||
                LifeInsurance.MaturityBenifit == string.Empty || LifeInsurance.ParticipationInProfits == string.Empty ||
                LifeInsurance.DeathBenefit == string.Empty || Convert.ToString(LifeInsurance.PlanParametersId)==string.Empty )
            { 
                errorMessage.Append("All Fields are Mandatory");
            }
          
           
            if (!valid)
            {
                throw new LifeException(errorMessage.ToString());
            }

            return valid;
        }


        public static bool AddLifeInsuranceBAL(LifeInsurance LifeInsurance)
        {
            bool LifeInsuranceAdded = false;
            try
            {
                if (ISValid(LifeInsurance))
                {
                    LifeDAL LifeDAL = new LifeDAL();
                    LifeInsuranceAdded = LifeDAL.AddLifeInsuranceDAL(LifeInsurance);
                    return LifeInsuranceAdded;
                }
            }
            catch (LifeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LifeInsuranceAdded;
        }

        public static bool UpdateLifeInsuranceBAL(LifeInsurance LifeInsurance)
        {
            bool LifeInsuranceUpdated = false;
            try
            {
                if (ISValid(LifeInsurance))
                {
                    LifeDAL LifeDAL = new LifeDAL();
                    LifeInsuranceUpdated = LifeDAL.UpdateLifeInsuranceDAL(LifeInsurance);
                    return LifeInsuranceUpdated;
                }
            }
            catch (LifeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LifeInsuranceUpdated;
        }

        public static bool DeleteLifeInsuranceBAL(int PlanNo)
        {
            bool LifeInsuranceDeleted = false;
            try
            {
                if (PlanNo > 0)
                {
                    LifeDAL LifeDAL = new LifeDAL();
                    LifeInsuranceDeleted = LifeDAL.DeleteLifeInsuranceDAL(PlanNo);
                }
                else
                {
                    throw new LifeException("PlanNo must be greater than 0.");
                }
            }
            catch (LifeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LifeInsuranceDeleted;
        }

        public static LifeInsurance SearchLifeInsuranceBAL(int employeeId)
        {
            LifeInsurance LifeInsurance = null;
            try
            {
                if (employeeId > 0)
                {
                    LifeDAL LifeDAL = new LifeDAL();
                    LifeInsurance = LifeDAL.SearchEmployeeDAL(employeeId);
                }
                else
                {
                    throw new LifeException("Employee Id must be greater than 0.");
                }
            }
            catch (LifeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LifeInsurance;
        }

        public static List<LifeInsurance> GetAllLifeInsuranceBAL()
        {
            List<LifeInsurance> LifeInsuranceList;
            try
            {
                LifeDAL LifeDAL = new LifeDAL();
                LifeInsuranceList = LifeDAL.GetAllLifeInsuranceDAL();
            }
            catch (LifeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LifeInsuranceList;
        }

        public static DataTable GetPlanParametersBAL()
        {
            DataTable PlanParametersList;
            try
            {
                LifeDAL LifeDAL = new LifeDAL();
                PlanParametersList = LifeDAL.GetPlanParametersDAL();
            }
            catch (LifeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return PlanParametersList;
        }

        
    }
}
